package javaCodes;
import java.util.*;

public class stackDemo {

	public static void main(String[] args) {
		Stack<String> stack = new Stack<>();
		
		Scanner sc= new Scanner(System.in);
		String newitem= sc.next(); 
		stack.push(newitem);

		
		System.out.println(stack);

		
	
	}

}
