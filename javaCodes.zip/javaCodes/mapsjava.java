package javaCodes;

public class mapsjava {

/* KEY VALUE - MAPS
 * MAP(Interface) - 1. Abstract Map(abstract class)  2. Sorted Map(abstract class)   3. HashTable(class)
	*/
	
	
}


