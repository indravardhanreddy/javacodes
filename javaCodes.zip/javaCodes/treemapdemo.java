package javaCodes;
import java.util.*;
public class treemapdemo {

	public static void main(String[] args) {
		TreeMap<Integer, Character> treeMap= new TreeMap<>();
		
		treeMap.put(1, 'A');
		treeMap.put(3, 'C');
		treeMap.put(2, 'V');
		
		System.out.println(treeMap);
	}

}
