package javaCodes;

import java.util.Scanner;

import com.sun.beans.introspect.PropertyInfo.Name;

import sun.java2d.marlin.DMarlinRenderingEngine;

public class Student {
	String name;
	int age;
	String address;
	
	public Student(String name,int age,String address) {
		this.name= name;
		this.age=age;
		this.address=address;
	}
	
	public void setName(String name) {
		this.name= name;
	}
	
	public void setAge(int age) {
		this.age= age;
	}
	
	public void setAddress(String address) {
		this.address= address;
	}
	
	public String getName() { 
		return name;
	}
	
	public String getAddress() {
		return address;
	}
	
	public int getAge() {
		return age;
	}
	
	
	public String toString() {
		return(this.getName()+ this.getAge());
	}
	public static void main(String[] args) {
		Scanner scanner= new Scanner(System.in);
		Student student= new Student("indra", 10, "bondaladinne");
//		name = scanner.next();
//		address = scanner.next();
//		age= scanner.nextInt();
		System.out.println(student.toString());
		
	}
	
	
}


