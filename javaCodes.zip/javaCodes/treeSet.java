package javaCodes;

import java.util.TreeSet;

public class treeSet {

	public static void main(String[] args) {
		
		TreeSet<String> treeSet = new TreeSet<>();
		TreeSet<String> treeSet2= new TreeSet<>();
		
		
		
		treeSet.add("hi");
		treeSet.add("hello");
	
		System.out.println(treeSet);
		
		treeSet.remove("hi");
		
		
		treeSet2.add("hello");
		
		
		System.out.println(treeSet2);
		
		if(treeSet.equals(treeSet2))
		{
			System.out.println("true");
		}
		
		
		System.out.println(treeSet);

	}

}
