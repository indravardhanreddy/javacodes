package javaCodes;

import java.util.Scanner;
import java.util.Stack;

public class stackexample {
	    public static void main(String[] args){
	        Scanner sc= new Scanner(System.in);
	        int n= sc.nextInt();
	        Stack<Integer> stack= new Stack<Integer>();
	        for(int i=0;i<n;i++){
	        	int inp= sc.nextInt();
	            int a= sc.nextInt();
	        switch(inp){
	            case 1:
	                stack.push(a);
	                inp=sc.nextInt();
	                break;
	            case 2:
	                stack.pop();
	                inp=sc.nextInt();
	                break;
	            case 3:
	                System.out.println(a);
	                break;
	        }
	        }
	    }

}
