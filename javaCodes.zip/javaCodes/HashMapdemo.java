package javaCodes;

import java.util.HashMap;

public class HashMapdemo {

		public static void main(String[] args) {
			HashMap<String,Integer> map = new HashMap<>();			
			map.put("a",10);
			map.put("c",20);
			map.put("b",30);
			map.put("a", 50);
			
//			System.out.println(map);
			
			if(map.containsKey("a")) {
				Integer acc = map.get("a");
//				System.out.println(acc);
			}
			
			for(String key:map.keySet()) {
//				System.out.println(key + map.get(key));
			}
			
			for(java.util.Map.Entry<String, Integer> entry: map.entrySet()) {
				System.out.println( entry.getValue());
			}
			
//			System.out.println(map.size());
//			System.out.println(map);
			
			
		}

}
