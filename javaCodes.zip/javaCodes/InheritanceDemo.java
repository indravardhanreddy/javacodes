package javaCodes;



public class InheritanceDemo {
	public static void main(String[] args) {
		MountainBike mountainBike= new MountainBike(20, 10, 2);
		System.out.println(mountainBike.gear);
		System.out.println(mountainBike.seatHeight);
		System.out.println(mountainBike.speed);
		mountainBike.applyBrake(2);
		System.out.println("After break - speed:"+ mountainBike.speed);
	}

}
