package javaCodes;
import java.util.*;
public class AccessModifiersDemo {
	
	

}
