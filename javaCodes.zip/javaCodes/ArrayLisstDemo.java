package javaCodes;
import java.util.*;
public class ArrayLisstDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Integer> arrlist= new ArrayList<Integer>();
//		Scanner sc= new Scanner(System.in);
//		int a =sc.nextInt();
		
		for(int i=0;i<=5;i++) {
			arrlist.add(i);
		}
		System.out.println(arrlist);
		
		arrlist.remove(3);
		System.out.println(arrlist);
		
		for(int j=0;j<arrlist.size();j++)
		{
			System.out.println(arrlist.get(j));
		}	
		
		for(int i:arrlist) {
			System.out.println(i);
		}
		

	}

}
