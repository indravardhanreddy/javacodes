package javaCodes;

public class MultipleConstructors {

	public static void main(String[] args) {
		
		

	}

}
