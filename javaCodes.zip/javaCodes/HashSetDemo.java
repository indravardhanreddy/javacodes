package javaCodes;

import java.util.HashSet;

public class HashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		HashSet<Integer> hashSet= new HashSet<Integer>();
		hashSet.add(1);
		hashSet.add(2);
		
		
		System.out.println(hashSet);

	}

}
