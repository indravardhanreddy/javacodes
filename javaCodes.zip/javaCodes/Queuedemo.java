package javaCodes;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;

public class Queuedemo {

	public static void main(String[] args) {
		Queue<Integer> demoQueue = new ConcurrentLinkedQueue();
		demoQueue.add(1);   
		demoQueue.add(5);
		demoQueue.add(2);
		demoQueue.add(4);
		
		System.out.println(demoQueue);
		
		// concurrentLinkedqueue  and priority queue
		
		demoQueue.remove();
		
		System.out.println(demoQueue);

		
	}

}
