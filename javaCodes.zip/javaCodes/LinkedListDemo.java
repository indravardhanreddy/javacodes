package javaCodes;

import java.util.LinkedList;

public class LinkedListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// add method get first get last add last
		
		LinkedList<String> linkedList = new LinkedList<String>();
		linkedList.add("a");
		linkedList.add("b");
		System.out.println(linkedList);
		linkedList.remove();
		linkedList.addFirst("z");
		linkedList.remove();
		System.out.println(linkedList);

	}

}
