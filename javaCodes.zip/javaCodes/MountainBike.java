package javaCodes;

public class MountainBike extends Bicycle{
	
	public int seatHeight;
	public int startHeight;
	
	public MountainBike(int startHeight, int startSpeed, int startGear) {
		super(startSpeed, startGear);
		this.startHeight= seatHeight;
	}
	
	public void setHeight(int newValue) {
		
		seatHeight= newValue;
	}

}
